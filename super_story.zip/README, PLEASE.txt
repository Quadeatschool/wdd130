This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://nhfonts.etsy.com/listing/1840724484/super-story-font

Tell your story with Super Story, a bubbly and casual font that's bursting with personality. Its rounded, playful characters evoke a sense of fun and adventure, making it the perfect choice for projects that aim to capture the imagination. From storybooks and comics to playful branding and social media graphics, Super Story adds a touch of whimsy and charm.